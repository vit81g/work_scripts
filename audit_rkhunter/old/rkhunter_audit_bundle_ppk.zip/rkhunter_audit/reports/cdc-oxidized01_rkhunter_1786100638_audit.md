# Аудит безопасности: cdc-oxidized01

- Файл: `cdc-oxidized01_rkhunter_1786100638.txt`
- SHA256: `91ebf8944bb1ee83eb08c8fe75eb607b90d0998fcb901cf74191135b79b95ac7`
- ОС (по журналу): Ubuntu 24.04.4 LTS
- rkhunter: 1.4.6
- Предупреждений `Warning:`: 10
- WARNING: 10; FAIL: 0; NOT_CHECKED: 13; PASS: 0

> WARNING — не доказательство компрометации. NOT_CHECKED — не подтверждено выполнение CIS/OWASP.

## Предупреждения и несоответствия

### RKH-COMMAND-SCRIPT — Системная команда определена как скрипт
**Результат:** WARNING | **Приоритет:** medium

**Доказательства (номер строки в исходном файле):**

- Строка 84: `Warning: The command '/usr/sbin/adduser' has been replaced by a script: /usr/sbin/adduser: Perl script text executable`
- Строка 133: `Warning: The command '/usr/bin/egrep' has been replaced by a script: /usr/bin/egrep: POSIX shell script, ASCII text executable`
- Строка 136: `Warning: The command '/usr/bin/fgrep' has been replaced by a script: /usr/bin/fgrep: POSIX shell script, ASCII text executable`
- Строка 151: `Warning: The command '/usr/bin/ldd' has been replaced by a script: /usr/bin/ldd: Bourne-Again shell script, ASCII text executable`
- Строка 216: `Warning: The command '/usr/bin/which.debianutils' has been replaced by a script: /usr/bin/which.debianutils: POSIX shell script, ASCII text executable`

**Рекомендация:** Проверить владельца пакета и контрольные суммы, сопоставить с доверенным дистрибутивом. Скрипт вместо бинарника может быть штатным для данной ОС; не заменять файл автоматически.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
dpkg -S /usr/bin/egrep /usr/bin/ldd /usr/sbin/adduser
dpkg -V grep libc-bin adduser 2>/dev/null || true
```

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-HASH — В базе rkhunter отсутствует эталонный хеш
**Результат:** WARNING | **Приоритет:** medium

**Доказательства (номер строки в исходном файле):**

- Строка 82: `Warning: No hash value found for file '/usr/local/bin/sestatus' in the 'rkhunter.dat' file.`

**Рекомендация:** Проверить источник и владельца файла; после подтверждения легитимности и исключения компрометации обновить доверенный baseline rkhunter (propupd).

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
dpkg -S /usr/local/bin/sestatus 2>/dev/null || true
sha256sum /usr/local/bin/sestatus
```

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-SSH-ROOT — Нет явного PermitRootLogin по мнению rkhunter
**Результат:** WARNING | **Приоритет:** medium

**Доказательства (номер строки в исходном файле):**

- Строка 1597: `Warning: The SSH configuration option 'PermitRootLogin' has not been set.`

**Рекомендация:** Проверить итоговую effective-конфигурацию sshd и соответствие выбранному CIS-профилю. Отсутствие строки в файле не доказывает разрешение root-входа; учесть Include и Match.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
sudo sshd -T | grep -i ^permitrootlogin
sudo grep -RniE "^[[:space:]]*(Include|PermitRootLogin|Match)" /etc/ssh/sshd_config /etc/ssh/sshd_config.d/ 2>/dev/null
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks), [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-SSH-PROTOCOL — Уведомление о параметре SSH Protocol
**Результат:** WARNING | **Приоритет:** low

**Доказательства (номер строки в исходном файле):**

- Строка 1600: `Warning: The SSH configuration option 'Protocol' has not been set.`

**Рекомендация:** Проверить версию OpenSSH и активную конфигурацию. Для современных OpenSSH параметр Protocol может отсутствовать штатно (используется SSHv2); само предупреждение не является нарушением CIS.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
sshd -V 2>&1
sudo sshd -T | head -30
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks), [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-HIDDEN — Скрытый файл
**Результат:** WARNING | **Приоритет:** medium

**Доказательства (номер строки в исходном файле):**

- Строка 1619: `Warning: Hidden file found: /etc/.resolv.conf.systemd-resolved.bak: ASCII text`
- Строка 1620: `Warning: Hidden file found: /etc/.updated: ASCII text`

**Рекомендация:** Определить происхождение скрытого файла, права и владельца. Сопоставить с пакетами, резервными копиями и политикой хранения секретов; не считать вредоносным по одному имени.

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/), [OWASP CI/CD Security Cheat Sheet — secure configuration](https://cheatsheetseries.owasp.org/cheatsheets/CI_CD_Security_Cheat_Sheet.html)

### RKH-STRINGS — Проверка strings пропущена
**Результат:** WARNING | **Приоритет:** low

**Доказательства (номер строки в исходном файле):**

- Строка 66: `Checking 'strings' command                        [ Skipped ]`

**Рекомендация:** Проверить наличие утилиты strings и обоснованность пропуска теста. Это недостаток полноты сканирования, а не автоматически нарушение CIS.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
command -v strings
dpkg -l binutils
```

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-DISABLED-TESTS — Отключены категории тестов rkhunter
**Результат:** WARNING | **Приоритет:** medium

**Доказательства (номер строки в исходном файле):**

- Строка 50: `Info: Disabled tests are: suspscan hidden_ports hidden_procs suspscan hidden_ports deleted_files packet_cap_apps hidden_procs running_procs`

**Рекомендация:** Пересмотреть список отключённых тестов с учётом накладных расходов и совместимости. Зафиксировать исключения и компенсирующие проверки.

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-PACKAGE-MGR — Проверка эталонных файлов не опирается на пакетный менеджер
**Результат:** WARNING | **Приоритет:** low

**Доказательства (номер строки в исходном файле):**

- Строка 47: `Info: No package manager specified: using hash function '/usr/bin/sha256sum'`

**Рекомендация:** Проверить настройки PKGMGR и доверенную базу rkhunter. Выбрать способ валидации целостности, пригодный для этой ОС.

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-MAIL — Отсутствует адрес для уведомлений rkhunter
**Результат:** WARNING | **Приоритет:** low

**Доказательства (номер строки в исходном файле):**

- Строка 19: `Info: No mail-on-warning address configured`

**Рекомендация:** Определить механизм доставки оповещений в KUMA/Zabbix/почту. Почтовый адрес в rkhunter необязателен, если уведомление организовано другим способом.

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-LOCK — Не используется блокировка параллельного запуска
**Результат:** WARNING | **Приоритет:** low

**Доказательства (номер строки в исходном файле):**

- Строка 57: `Info: Locking is not being used`

**Рекомендация:** Проверить защиту от одновременных запусков на уровне планировщика.

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

## Требования ГК ППК — отдельная колонка соответствия

Источник: `linux.md` (редакция 1.1, 11.2025).
По журналу rkhunter нельзя подтвердить большинство настроек ОС. Отсутствие данных = NOT_CHECKED, не FAIL.

| Пункт | Требование ГК ППК | Ожидается | Факт | Соответствие ГК ППК | Риск применения |
|---|---|---|---|---|---|
| 1.1 | Запрет пустых паролей | none | нет данных | NOT_CHECKED | Нет |
| 1.2 | Запрет root-входа по SSH | no | rkhunter: Warning: The SSH configuration option 'PermitRootLogin' has not been set. | NOT_CHECKED | Риск блокировки аварийного доступа; нужен sudo-пользователь |
| 1.3 | Ограничение su через pam_wheel | auth required pam_wheel.so use_uid | нет данных | NOT_CHECKED | Пользователи вне группы wheel потеряют su |
| 1.4 | Проверка конфигурации sudo | valid | нет данных | NOT_CHECKED | Ошибка в sudoers может заблокировать администрирование |
| 2.1 | Права /etc/passwd и /etc/group | 644 | нет данных | NOT_CHECKED | Нет по документу |
| 2.1b | Права /etc/shadow | 600 | нет данных | NOT_CHECKED | Нет по документу |
| 2.2 | Запрет записи group/other в cron | go-w | нет данных | NOT_CHECKED | Нет по документу |
| 2.3 | Аудит SUID/SGID файлов | reviewed | нет данных | NOT_CHECKED | Удаление SUID может нарушить работу программ |
| 2.4 | Права домашних каталогов | 700 | нет данных | NOT_CHECKED | Нет по документу |
| 3.1 | Защита журнала ядра | 1 | нет данных | NOT_CHECKED | Нет по документу |
| 3.2 | Ограничение kallsyms | 2 | нет данных | NOT_CHECKED | Нет по документу |
| 3.3a | Минимальный адрес mmap | 4096 | нет данных | NOT_CHECKED | Нет по документу |
| 3.3b | ASLR | 2 | нет данных | NOT_CHECKED | Нет по документу |
| 3.4 | ptrace | 3 | нет данных | NOT_CHECKED | Могут перестать работать инструменты мониторинга и профилирования; требуется тест |
| 3.5a | Защита symlinks | 1 | нет данных | NOT_CHECKED | Нет по документу |
| 3.5b | Защита hardlinks | 1 | нет данных | NOT_CHECKED | Нет по документу |
| 3.6a | Защита FIFO | 2 | нет данных | NOT_CHECKED | Нет по документу |
| 3.6b | Защита регулярных файлов | 2 | нет данных | NOT_CHECKED | Нет по документу |
| 3.7 | Запрет SUID core dump | 0 | нет данных | NOT_CHECKED | Нет по документу |
| 3.8 | Запрет user namespaces | 0 | нет данных | NOT_CHECKED | Может нарушить Docker, containerd, Podman, sandbox браузеров |
| 3.9a | Ограничение unprivileged eBPF | 1 | нет данных | NOT_CHECKED | Может нарушить сетевые агенты, интеграции MaxPatrol и KUMA |
| 3.9b | Защита BPF JIT | 2 | нет данных | NOT_CHECKED | Может нарушить сетевые агенты, интеграции MaxPatrol и KUMA |
| 3.10 | Ограничение perf | 3 | нет данных | NOT_CHECKED | Возможна несовместимость с профилированием и MaxPatrol |
| 4.1 | Инициализация памяти нулями | 1 | нет данных | NOT_CHECKED | Возможна деградация производительности; цифры исходного документа отдельно не проверены |
| 4.2 | Запрет объединения slab | present | нет данных | NOT_CHECKED | Возможны потери производительности |
| 4.3 | Выключение TSX | off | нет данных | NOT_CHECKED | Возможны потери производительности |
| 4.4a | IOMMU force | force | нет данных | NOT_CHECKED | Возможны проблемы виртуализации и производительности сети |
| 4.4b | IOMMU strict | 1 | нет данных | NOT_CHECKED | Возможны проблемы виртуализации и производительности сети |
| 4.4c | IOMMU passthrough | 0 | нет данных | NOT_CHECKED | Возможны проблемы виртуализации и производительности сети |
| 4.5 | Отключение vsyscall | none | нет данных | NOT_CHECKED | Старые программы могут перестать работать |
| 4.6 | Отключение debugfs | no-mount | нет данных | NOT_CHECKED | Некоторые драйверы используют debugfs |

### Как собрать подтверждающие данные

Правила содержатся в `ppk_linux_rules.json`. Команды ниже выполняются вручную на проверяемом сервере,
скрипт анализирует только файлы, ничего не меняет на удалённых системах.

- **1.1 Запрет пустых паролей** — `awk -F: '($2=="") {print $1}' /etc/shadow`; статус: NOT_CHECKED
- **1.2 Запрет root-входа по SSH** — `sshd -T | grep -i ^permitrootlogin`; статус: NOT_CHECKED
- **1.3 Ограничение su через pam_wheel** — `grep -n pam_wheel /etc/pam.d/su`; статус: NOT_CHECKED
- **1.4 Проверка конфигурации sudo** — `visudo -c`; статус: NOT_CHECKED
- **2.1 Права /etc/passwd и /etc/group** — `stat -c "%a %n" /etc/passwd /etc/group`; статус: NOT_CHECKED
- **2.1b Права /etc/shadow** — `stat -c "%a %n" /etc/shadow`; статус: NOT_CHECKED
- **2.2 Запрет записи group/other в cron** — `stat -c "%a %n" /etc/crontab /etc/cron.d/*`; статус: NOT_CHECKED
- **2.3 Аудит SUID/SGID файлов** — `find / -perm /6000 -type f 2>/dev/null`; статус: NOT_CHECKED
- **2.4 Права домашних каталогов** — `stat -c "%a %n" /home/*`; статус: NOT_CHECKED
- **3.1 Защита журнала ядра** — `sysctl kernel.dmesg_restrict`; статус: NOT_CHECKED
- **3.2 Ограничение kallsyms** — `sysctl kernel.kptr_restrict`; статус: NOT_CHECKED
- **3.3a Минимальный адрес mmap** — `sysctl vm.mmap_min_addr`; статус: NOT_CHECKED
- **3.3b ASLR** — `sysctl kernel.randomize_va_space`; статус: NOT_CHECKED
- **3.4 ptrace** — `sysctl kernel.yama.ptrace_scope`; статус: NOT_CHECKED
- **3.5a Защита symlinks** — `sysctl fs.protected_symlinks`; статус: NOT_CHECKED
- **3.5b Защита hardlinks** — `sysctl fs.protected_hardlinks`; статус: NOT_CHECKED
- **3.6a Защита FIFO** — `sysctl fs.protected_fifos`; статус: NOT_CHECKED
- **3.6b Защита регулярных файлов** — `sysctl fs.protected_regular`; статус: NOT_CHECKED
- **3.7 Запрет SUID core dump** — `sysctl fs.suid_dumpable`; статус: NOT_CHECKED
- **3.8 Запрет user namespaces** — `sysctl user.max_user_namespaces`; статус: NOT_CHECKED
- **3.9a Ограничение unprivileged eBPF** — `sysctl kernel.unprivileged_bpf_disabled`; статус: NOT_CHECKED
- **3.9b Защита BPF JIT** — `sysctl net.core.bpf_jit_harden`; статус: NOT_CHECKED
- **3.10 Ограничение perf** — `sysctl kernel.perf_event_paranoid`; статус: NOT_CHECKED
- **4.1 Инициализация памяти нулями** — `cat /proc/cmdline`; статус: NOT_CHECKED
- **4.2 Запрет объединения slab** — `cat /proc/cmdline`; статус: NOT_CHECKED
- **4.3 Выключение TSX** — `cat /proc/cmdline`; статус: NOT_CHECKED
- **4.4a IOMMU force** — `cat /proc/cmdline`; статус: NOT_CHECKED
- **4.4b IOMMU strict** — `cat /proc/cmdline`; статус: NOT_CHECKED
- **4.4c IOMMU passthrough** — `cat /proc/cmdline`; статус: NOT_CHECKED
- **4.5 Отключение vsyscall** — `cat /proc/cmdline`; статус: NOT_CHECKED
- **4.6 Отключение debugfs** — `cat /proc/cmdline`; статус: NOT_CHECKED

Для автоматической оценки можно передать JSON-снимки фактических параметров, например `evidence/<имя_хоста>.json`.

## Непроверенные требования и контрольные процедуры

### RKH-ROOTKIT — Обнаружение сигнатуры rootkit
**Результат:** NOT_CHECKED | **Приоритет:** high

Достаточных сведений в журнале нет.

**Рекомендация:** Приоритетное расследование: проверить детальные артефакты соответствующего теста, повторить проверку независимыми средствами и сверить системные пакеты. Не считать подтверждённой компрометацией без верификации.

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-SSH-DIFFER — Различие оценок конфигурации SSH
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** Сопоставить /etc/rkhunter.conf и фактический effective sshd -T; уточнить источник расхождения.

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/), [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks)

### RKH-DEV — Подозрительные типы файлов в /dev
**Результат:** NOT_CHECKED | **Приоритет:** high

Достаточных сведений в журнале нет.

**Рекомендация:** Изучить последующие строки журнала и идентифицировать файлы /dev, проверить тип, владельца и предназначение. Не удалять без подтверждения.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
sudo find /dev -xdev -type f -ls 2>/dev/null
```

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-USER-ADDED — Добавлен пользователь
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** Проверить владельца изменения, историю установки пакетов и необходимость учётной записи, затем согласовать или расследовать.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
getent passwd
sudo grep -i "install\|upgrade" /var/log/dpkg.log | tail -30
```

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### RKH-GROUP-ADDED — Добавлена группа
**Результат:** NOT_CHECKED | **Приоритет:** low

Достаточных сведений в журнале нет.

**Рекомендация:** Проверить связь с пакетом, сервисом и авторизованным изменением.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
getent group
```

**Источники:** [rkhunter — validation and false positives](https://sourceforge.net/p/rkhunter/wiki/validate/)

### CIS-SSH-EFFECTIVE — Проверка эффективных настроек SSH
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** rkhunter не содержит достаточных данных. Выполнить отдельную проверку конфигурации и сопоставить с конкретной версией/профилем контрольного документа.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
sudo sshd -T
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks)

### CIS-PASSWORD — PAM и политика паролей
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** rkhunter не содержит достаточных данных. Выполнить отдельную проверку конфигурации и сопоставить с конкретной версией/профилем контрольного документа.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
sudo cat /etc/security/pwquality.conf
sudo grep -Rni pam_pwquality /etc/pam.d/
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks)

### CIS-FIREWALL — Локальный межсетевой экран
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** rkhunter не содержит достаточных данных. Выполнить отдельную проверку конфигурации и сопоставить с конкретной версией/профилем контрольного документа.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
sudo nft list ruleset
sudo ufw status verbose
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks)

### CIS-AUDIT — Настройки auditd и журналирования
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** rkhunter не содержит достаточных данных. Выполнить отдельную проверку конфигурации и сопоставить с конкретной версией/профилем контрольного документа.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
systemctl is-enabled auditd
sudo auditctl -s
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks)

### CIS-SYSCTL — Параметры защиты ядра и сетевого стека
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** rkhunter не содержит достаточных данных. Выполнить отдельную проверку конфигурации и сопоставить с конкретной версией/профилем контрольного документа.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
sudo sysctl -a
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks)

### CIS-FILESYSTEM — Разделы и параметры монтирования
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** rkhunter не содержит достаточных данных. Выполнить отдельную проверку конфигурации и сопоставить с конкретной версией/профилем контрольного документа.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
findmnt -o TARGET,OPTIONS
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks)

### CIS-UPDATES — Обновления пакетов
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** rkhunter не содержит достаточных данных. Выполнить отдельную проверку конфигурации и сопоставить с конкретной версией/профилем контрольного документа.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
apt list --upgradable 2>/dev/null
```

**Источники:** [CIS Benchmarks — Ubuntu Linux / выбрать версию и профиль](https://www.cisecurity.org/cis-benchmarks)

### OWASP-WEB — Проверка веб-приложения по OWASP WSTG
**Результат:** NOT_CHECKED | **Приоритет:** medium

Достаточных сведений в журнале нет.

**Рекомендация:** rkhunter не содержит достаточных данных. Выполнить отдельную проверку конфигурации и сопоставить с конкретной версией/профилем контрольного документа.

**Команды для ручной проверки на целевом хосте (не выполняются скриптом):**

```bash
# Потребуются конфигурации веб-сервера и результаты тестирования приложения
```

**Источники:** [OWASP CI/CD Security Cheat Sheet — secure configuration](https://cheatsheetseries.owasp.org/cheatsheets/CI_CD_Security_Cheat_Sheet.html)
