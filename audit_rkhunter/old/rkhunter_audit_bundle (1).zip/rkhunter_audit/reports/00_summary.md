# Сводный анализ rkhunter

Дата анализа (UTC): 2026-10-12T07:44:20.169243+00:00

| Хост | ОС | Предупреждения rkhunter | WARNING | FAIL | NOT_CHECKED |
|---|---|---:|---:|---:|---:|
| cdc-graylog01 | Ubuntu 24.04.4 LTS | 10 | 10 | 0 | 13 |
| cdc-oxidized01 | Ubuntu 24.04.4 LTS | 10 | 10 | 0 | 13 |
| cdc-unifi01 | Ubuntu 24.04.4 LTS | 10 | 10 | 0 | 13 |
| cplus-ansible-node01 | Astra Linux | 12 | 12 | 0 | 11 |
| cplus-netbox02 | Ubuntu 24.04.4 LTS | 10 | 9 | 0 | 14 |
| astra-96185 | Astra Linux | 9 | 9 | 0 | 14 |
| ppk-b24-db-kpi | Astra Linux | 9 | 10 | 0 | 13 |
| ppk-b24-db01 | Astra Linux | 9 | 10 | 0 | 13 |

**Внимание:** значения WARNINGS/FAIL отражают правила этого анализатора, а не результат сертификационного CIS-аудита.

Для полного CIS Benchmark требуется отдельный сбор параметров ОС, а для web-приложений — проверки по OWASP WSTG.